﻿Public Class NhanVien
    Public Property MANV As Integer
    Public Property MACV As Integer
    Public Property TENNV As String
    Public Property CMND As String
    Public Property NGAYSINH As String
    Public Property DIACHI As String
    Public Property DIENTHOAI As String
    Public Property EMAIL As String
    Public Property GHICHU As String

    Public Sub NhanVien()

    End Sub
End Class
