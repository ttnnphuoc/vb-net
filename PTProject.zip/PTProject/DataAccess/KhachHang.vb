﻿Public Class KhachHang
    Public Property MAKH As Integer
    Public Property TENKH As String
    Public Property DIENTHOAI As String
    Public Property DIACHI As String
    Public Property EMAIL As String
    Public Property FAX As String
    Public Property GHICHU As String
    Public Property THANG As String

    Public Sub KhachHang()

    End Sub
End Class
