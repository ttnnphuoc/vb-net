﻿Public Class CTPhieuThu
    Public Property MATHU As Integer
    Public Property MAXUAT As String
    Public Property SOHD As String
    Public Property NGAYHD As Date
    Public Property SOTIENBAN As Decimal
    Public Property SOTIENTHU As Decimal
    Public Property CONLAI As Decimal
    Public Property LUUMAXUAT As Boolean
    Public Property GHICHU As String

    Public Sub CTPhieuThu()

    End Sub
End Class
