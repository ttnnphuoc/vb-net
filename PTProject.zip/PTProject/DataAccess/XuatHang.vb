﻿Public Class XuatHang
    Public Property MAXUAT As Integer
    Public Property MAKHO As String
    Public Property MANV As Integer
    Public Property MAKH As Integer
    Public Property TENPX As String
    Public Property CHUNGTUNGOC As String
    Public Property VANCHUYEN As String
    Public Property LUUMAXUAT As Boolean
    Public Property GHICHU As String
    Public Property CONLAI As Integer
    Public Property NGAYHD As Date
    Public Property NGAYTRA As Date
    Public Property NGAYXUAT As Date
    Public Sub XuatHang()

    End Sub
End Class
