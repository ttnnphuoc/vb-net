﻿Public Class ChucVu
    Public Property MACV As Integer
    Public Property TENCV As String
    Public Property GHICHU As String

    Public Sub ChucVu()

    End Sub
End Class
