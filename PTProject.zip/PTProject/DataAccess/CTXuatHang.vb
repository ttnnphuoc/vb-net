﻿Public Class CTXuatHang
    Public Property MAXUAT As Integer
    Public Property MAVT As String
    Public Property DONGIAX As Decimal
    Public Property SOLUONGX As Integer
    Public Property VAT As Decimal
    Public Property THANHTIENX As Decimal
    Public Property DVT As String
    Public Property LUUMAXUAT As Boolean
    Public Property GHICHU As String
    Public Property TENVT As String
    Public Sub CTXuatHang()

    End Sub
End Class
