﻿Public Class Kho
    Public Property MAKHO As Integer
    Public Property DIACHI As String
    Public Property GHICHU As String
    Public Property TENKHO As String
    Public Property EMAIL As String
    Public Property DIENTHOAI As String

    Public Sub Kho()

    End Sub
End Class
