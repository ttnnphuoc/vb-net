﻿Public Class PhieuThu
    Public Property MATHU As Integer
    Public Property MAKH As Integer
    Public Property TENPT As String
    Public Property NGAYT As String
    Public Property SOTIENT As Decimal
    Public Property GHICHU As String

    Public Sub PhieuThu()

    End Sub
End Class
